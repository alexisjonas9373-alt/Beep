const Discord = require(`discord.js`);
const { MessageEmbed } = require(`discord.js`);
const config = require(`${process.cwd()}/botconfig/config.json`);
const ee = require(`${process.cwd()}/botconfig/embed.json`);
const emoji = require(`${process.cwd()}/botconfig/emojis.json`);
const playermanager = require(`../../handlers/playermanager`);
const { allEmojis } = require("../../botconfig/emojiFunctions");
const { handlemsg } = require(`${process.cwd()}/handlers/functions`);
module.exports = {
    name: `playprevious`,
    category: `🎶 Music`,
    aliases: [`pp`, `ppre`, `playprevius`, `playprevios`],
    description: `Plays the Previous played Song and skips the current Song`,
    usage: `playprevious`,
    parameters: {
        type: "music",
        activeplayer: true,
        check_dj: true,
        previoussong: true,
    },
    type: "song",
    run: async (client, message, args, cmduser, text, prefix, player) => {
        let es = client.settings.get(message.guild.id, "embed");
        let ls = client.settings.get(message.guild.id, "language");
        if (!client.settings.get(message.guild.id, "MUSIC")) {
            return message.reply({
                embeds: [
                    new MessageEmbed()
                        .setColor(es.wrongcolor)
                        .setFooter(client.getFooter(es))
                        .setTitle(client.la[ls].common.disabled.title)
                        .setDescription(handlemsg(client.la[ls].common.disabled.description, { prefix: prefix })),
                ],
            });
        }
        try {
            //define the type
            let type = `skiptrack:youtube`;
            //if the previous was from soundcloud, then use type soundcloud
            if (player.queue.previous.uri?.includes(`soundcloud`)) type = `skiptrack:soundcloud`;
            //plays it
            if (type != "skiptrack:soundcloud") message.react(allEmojis.msg.youtube).catch(() => {});
            else message.react(allEmojis.msg.soundcloud).catch(() => {});
            playermanager(client, message, Array(player.queue.previous.uri), type);
        } catch (e) {
            console.log(String(e.stack).dim.bgRed);
            return message.reply({
                embeds: [
                    new MessageEmbed()
                        .setColor(es.wrongcolor)

                        .setTitle(client.la[ls].common.erroroccur)
                        .setDescription(eval(client.la[ls]["cmds"]["music"]["playprevious"]["variable1"])),
                ],
            });
        }
    },
};
/**
 * @INFO
 * Bot Coded by Tomato#6966 | https://github?.com/Tomato6966/discord-js-lavalink-Music-Bot-erela-js
 * @INFO
 * Work for Milrato Development | https://milrato.eu
 * @INFO
 * Please mention Him / Milrato Development, when using this Code!
 * @INFO
 */
