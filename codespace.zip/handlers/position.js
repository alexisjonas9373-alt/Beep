/**
 * Moved to ./functions.js
 */
