/**
 * MOVED TO .counter.js
 */
